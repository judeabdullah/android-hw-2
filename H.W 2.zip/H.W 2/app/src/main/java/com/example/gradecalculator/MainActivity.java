package com.example.gradecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView title = findViewById(R.id.textView);
       final EditText q = findViewById(R.id.editTextTextPersonName);
       final EditText h = findViewById(R.id.editTextTextPersonName2);
        final EditText m = findViewById(R.id.editTextTextPersonName3);
       final EditText f = findViewById(R.id.editTextTextPersonName4);
       final Button calculate = findViewById(R.id.button);
       final TextView result = findViewById(R.id.textView2);

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a = Integer.parseInt(q.getText().toString());
                int b = Integer.parseInt(h.getText().toString());
                int c = Integer.parseInt(m.getText().toString());
                int d = Integer.parseInt(f.getText().toString());
                int total = a + b + c + d ;
                result.setText(total+ "");


            }
        });
    }
}